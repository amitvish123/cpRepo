#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll fact(ll n){
    if(n==0||n==1)
        return 1;
    else
        return n*fact(n-1);
}
void solve()
{
    string s;
    cin>>s;
    sort(s.begin(),s.end());
    ll n= s.length();
    ll a[26];
    memset(a,0,sizeof(a));
    for(ll i=0;i<n;i++){
        a[s[i]-'a']++;
    }
    ll p=1;
    for(ll i=0;i<26;i++){
        if(a[i]>1){
            p*=fact(a[i]);
        }
        
    }
    ll ans= fact(n)/p;
    cout<<ans<<endl;
   // cout<<s<<endl;
    do
    {
        cout<<s<<endl;
    }while(next_permutation(s.begin(),s.end()));
    //cout<<s;
}
int main(){
    solve();

}