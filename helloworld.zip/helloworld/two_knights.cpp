#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
    ll z;
    cin>>z;
    for(ll n=1;n<=z;n++){
        
        ll ans=((n*n)*(n*n-1))/2;
        if(n>2){
            ans-= 4*(n-1)*(n-2);
        }
        cout<<ans<<endl;
    }
}
int main(){
   solve();
}