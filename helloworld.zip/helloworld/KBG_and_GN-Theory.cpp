#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())



    

void solve(){
    ll MAXN=100001;
    ll spf[MAXN];
    ll n,q;
    cin>>n>>q;
    ll u[q],v[q];
    forn(i,q){
        cin>>u[i]>>v[i];
    }
     spf[1] = 1;
    for (ll i=2; i<MAXN; i++)
 
        // marking smallest prime factor for every
        // number to be itself.
        spf[i] = i;
 
    // separately marking spf for every even
    // number as 2
    for (ll i=4; i<MAXN; i+=2)
        spf[i] = 2;
 
    for (ll i=3; i*i<MAXN; i++)
    {
        // checking if i is prime
        if (spf[i] == i)
        {
            // marking SPF for all numbers divisible by i
            for (ll j=i*i; j<MAXN; j+=i)
 
                // marking spf[j] if it is not
                // previously marked
                if (spf[j]==j)
                    spf[j] = i;
        }
    }
 
    forn(i,q){
        ll gcd= __gcd(u[i],v[i]);
        if(gcd==u[i]|| gcd==v[i]){
            cout<<max(u[i],v[i])/gcd<<ln;continue;
        }
        ll ans=0;
        // while(gcd!=1){
        //     u[i]=u[i]/gcd;v[i]=v[i]/gcd;
        //     ans+=(2*gcd);
        //     gcd= __gcd(u[i],v[i]);
        // }
        vll v,vv;
        ll x= u[i],y=v[i];
        while(x!=1){
            v.push_back(spf[x]);
            x/=spf[x];
        }
        while(y!=1){
            vv.push_back(spf[y]);
            y/=spf[y];
        }
        
        ll t1= spf[u[i]],t2= spf[v[i]];
        if(u[i]!= t1 and v[i]!= t2){
            ans+=(u[i]/t1+v[i]/t2);
        }
        ans+=(t1+t2);
        //ans+=(u[i]+v[i]);
        cout<<ans<<ln;
    }



}
int main()
{
    fast_cin();
    ll t;
    cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}