#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
 
bool col[8], diag1[14], diag2[14],reserved[8][8];
int ways=0;
void search(int r){
    if(r==8 ){
        ways++;
        return;
    }else{
        for(int i=0;i<8;i++){
            if(col[i]||diag1[r+i]||diag2[r-i+7]||reserved[r][i]){
                continue;
            }
            col[i]=diag1[r+i]= diag2[r-i+7]=true;
            search(r+1);
            col[i]=diag1[r+i]= diag2[r-i+7]=false;
        }
    }
}
void solve(){
    
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            reserved[i][j]=false;
        }
    }
    for(int i=0;i<14;i++){
        diag1[i]=diag2[i]=false;
    }
    for(int i=0;i<8;i++){
        col[i]=false;
    }
    string s;
    
    for(int i=0;i<8;i++){   
        for(int j=0;j<8;j++){
            char x;
            cin>>x;
            if(x!='.'){
                reserved[i][j]= true;
            }
        }
    }
    search(0);
    cout<<ways;

}
int main()
{
    fast_cin();
    ll t=1;
    //cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}