#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
    string s;
    cin>>s;
    map<char,ll> m;
    for(ll i=0;i<s.length();i++){
        m[s[i]]++;
    }
    ll c=0;
    char temp;ll temp1;
    string tmp;
    for(auto x:m){
        if(x.second%2!=0){
            c++;temp= x.first;temp1= x.second;
        }
    }
    if(c>1){
        cout<<"NO SOLUTION";return;
    }
    else{
        for(auto x:m){
           if(x.second%2==0){
            string str(x.second/2, x.first);
            tmp.append(str);
            }
        }
        string tmp1=tmp;
        reverse(tmp.begin(), tmp.end());
        if(c==0){
            
            tmp+=tmp1;
        }else{
            string str(temp1,temp);
            tmp.append(str);
            tmp+=tmp1;
        }
        cout<<tmp;
    }
}
int main(){
    solve();

}