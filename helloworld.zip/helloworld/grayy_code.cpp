#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve()
{
    ll n;
    cin>>n;
    for(ll i=0;i<1<<n;i++){
        ll x= i^(i>>1);
        string s;
        ll p=0;
        while(x){
            if(x&1){
                s+='1';
            }else{
                s+='0';
            }
            x>>=1;
            p++;
        }
        for(ll i=0;i<n-p;i++){
            s.push_back('0');
        }
        reverse(s.begin(),s.end());
        cout<<s<<endl;
    }
}
int main(){
    solve();
}