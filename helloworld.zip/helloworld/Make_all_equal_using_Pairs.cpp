#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve(){
    int n;cin>>n;
    int a[n];vector<int> cnt(1005,0);

    for(int i=0;i<n;i++){
        cin>>a[i];
        cnt[a[i]]++;
    }
    int maxx= INT_MIN;
    for(int i=0;i<n;i++){
        maxx= max(maxx,cnt[a[i]]);
    }
    cout<<n-maxx;
}
int main(){
    int t;cin>>t;
    while(t--){
        solve();cout<<endl;
    }
}