#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
    int n,x;cin>>n>>x;
        int a[n];
        for(int i=0;i<n;i++){
            cin>>a[i];
        }
        if(n==1){
            cout<<"YES"<<endl;return;
        }
        int s=0;
        for(int i=1;i<n;){
            
            if(a[i-1]>a[i]){
                s+=a[i-1];
                s+=a[i];i+=2;
            }
            else{
                if(s>x){
                    cout<<"NO"<<endl;return;
                }
                else{
                    reverse()
                    s=0;i++;
                }
            }
        }
        if(s>x){
            cout<<"NO"<<endl;
        }else{
            cout<<"YES"<<endl;
        }
    

}
int main(){
    int t;cin>>t;
    while(t--){
        solve();
    }
}