#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
 

void solve(){
    ll m,n;
    cin>>m>>n;
    ll a[m][n];
    forn(i,m){
        forn(j,n)
        cin>>a[i][j];
    }
    
    vector<ll> v;
    set<ll> temp;
    for(ll i=1;i<n;i++){
        if(a[0][i-1]>a[0][i]){
            temp.insert(i);temp.insert(i-1);
        }
    }
    
    
    if(temp.size()>2){
        if(temp.size()==3){
            int d=0;
            for(auto x:temp){
                if(d!=1){
                    v.push_back(x);
                }d++;
            }
        }else{
            cout<<-1;return;
        }
    }
    else if(temp.size()==0){
        v.push_back(0);
        v.push_back(0);
    }else{
        for(auto x:temp){
            v.push_back(x);
        }
    }
    for(ll i=1;i<m;i++){
        
        set<ll> s;
        set<ll> tmp;
        tmp.insert(a[i][0]);
        for(ll j=1;j<n;j++){
            //c[i]=a[i][j];
            tmp.insert(a[i][j]);
            if(a[i][j-1]> a[i][j]){
                s.insert(j);s.insert(j-1);
            }
        }
        if(s.size()==0 ){
            if(tmp.size()==1){
                s.insert(v[0]);
                s.insert(v[1]);
            }else{
                if(v[0]!= 0|| v[1]!= 0){
                    cout<<-1;return;
                }
            }
        }
        if(s.size()>2){
            if(s.size()==3 ){
                ll d=0,e=0;
                bool flag=false;
                for(auto x:s){
                    if(d!=1 and x== v[e]){
                        e++;flag=true;
                    }d++;
                }
                if(flag){
                    s.insert(v[0]);
                    s.insert(v[1]);
                }else{
                    cout<<-1;return;
                }
            }else{
            cout<<-1;return;}
        }
        else{
            auto it= s.find(v[0]);
            auto itr= s.find(v[1]);
            if(it== s.end() || itr== s.end()){
                cout<<-1;return;
            }
        }
        
    }
    for(auto &x: v){
        cout<<x+1<<" ";
    }
}
int main()
{
    fast_cin();
    ll t;
    cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}