#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve()
{
    ll n;cin>>n;
    ll a[n];
    ll s=0;
    for(ll i=0;i<n;i++)
    {
        cin>>a[i];
        s+=a[i];
    }
    sort(a,a+n);
    ll minn=INT_MAX;
    ll c=0;
   
    cout<<minn<<endl;
}
int main()
{
    solve();
}