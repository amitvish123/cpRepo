#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())


 
int longestPalSubstr(string text)
{
    int N = text.length();
    if(N == 0)
        return 0;
    N = 2*N + 1; 
    int L[N]; 
    L[0] = 0;
    L[1] = 1;
    int C = 1; 
    int R = 2; 
    int i = 0;
    int iMirror; 
    int maxLPSLength = 0;
    int maxLPSCenterPosition = 0;
    int start = -1;
    int end = -1;
    int diff = -1;
     
    
    for (i = 2; i < N; i++)
    {
        iMirror = 2*C-i;
        L[i] = 0;
        diff = R - i;
        if(diff > 0)
            L[i] = min(L[iMirror], diff);
 
        while ( ((i + L[i]) < N && (i - L[i]) > 0) &&
            ( ((i + L[i] + 1) % 2 == 0) ||
            (text[(i + L[i] + 1)/2] == text[(i - L[i] - 1)/2] )))
        {
            L[i]++;
        }
 
        if(L[i] > maxLPSLength) 
        {
            maxLPSLength = L[i];
            maxLPSCenterPosition = i;
        }
 
        //If palindrome centered at currentRightPosition i
        //expand beyond centerRightPosition R,
        //adjust centerPosition C based on expanded palindrome.
        if (i + L[i] > R)
        {
            C = i;
            R = i + L[i];
        }
        //Uncomment it to print LPS Length array
        //printf("%d ", L[i]);
    }
    //printf("\n");
    return *max_element(L,L+N);
}
void solve(){
    int n;cin>>n;
    vector<string> arr;
    for(int i=0;i<n;i++){
        string x;
        cin>>x;
        arr.push_back(x);
    }
    int dp[n];
    dp[0]=1;
    vector<int> v;
    for(int i=0;i<n;i++){
        v.push_back(findLongestPalindromicString(arr[i]));
    }
    for(int i=1;i<=n;i++){
        dp[i]=1;
        for(int j=0;j<i;j++){
            if(v[j]<=v[i]){
                dp[i]= max(dp[i],dp[j]+1);
            }
        }
    }
    cout<< *max_element(dp,dp+n);
    
}

int main()
{
    fast_cin();
    ll t=1;
   // cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}