    #include <bits/stdc++.h>
    using namespace std;
    typedef long long ll;

    int main(){
        ll n;cin>>n;
        while(n--){
            ll a,b;
            cin>>a>>b;
            if((a+b)%3==0){
                if(abs(a-b)<= (a+b)/2){
                    cout<<"YES"<<endl;
                }else{
                    cout<<"NO"<<endl;
                }
            }else{
                cout<<"NO"<<endl;
            }
        }
    }