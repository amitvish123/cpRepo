#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll c=0;
void toh(ll n,ll l,ll m, ll r){
    if(n==0){
        return;
    }
    toh(n-1,l, r, m);c++;
    cout<<l<<" "<<r<<endl;
    toh(n-1,m,l,r);

}
int main(){
    ll n;cin>>n;
    cout<<((1<<n)-1)<<endl;
    toh(n,1,2,3);
}