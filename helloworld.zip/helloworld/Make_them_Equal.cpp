#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
 

void solve(){
    ll x,y,z;
    cin>>x>>y>>z;
    ll a[3]={x,y,z};
    sort(a,a+3);
    ll s=(a[2]-a[1]);ll ss= (a[2]-a[0]);
    // ll p=s,d=s,pp=ss,dd=pp;
    // bool f=false;
    // ll i=0,j=0;
    // while(p>0){
    //     p-=(1<<i);
    //     i++;
    // }
    // while(pp>0){
    //     pp-=(1<<j);
    //     j++;
    // }
    // if(p==0){
    //     while(dd>0){
    //         dd-=(1<<i);
    //         i++;
    //     }
    //     if(dd==0){
    //         f=true;
    //     }
    // }else{
    //     if(pp==0){
    //         while(d>0){
    //             d-=(1<<j);
    //             j++;
    //         }
    //         if(d==0){
    //             f=true;
    //         }
    //     }
    // }
    // if(f){
        if(a[0]==a[2]){
            cout<<"YES";return;
        }
        ll maxx= (ll)log2(ss);
        for(ll i=0;i<=maxx;i++){
            if((s&(1<<i)) == (ss&(1<<i))){
                cout<<"NO";return;
            }
        }
        cout<<"YES";
    // }else{
    //  cout<<"NO";
    // }
    
}
int main()
{
    fast_cin();
    int t;
    cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}