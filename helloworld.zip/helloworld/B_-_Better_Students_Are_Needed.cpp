#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
int lis(int arr[], int n)
{
    int *lis, i, j, max = 0;
    lis = (int*)malloc(sizeof(int) * n);
 
    /* Initialize LIS values for all indexes */
    for (i = 0; i < n; i++)
        lis[i] = 1;
 
    /* Compute optimized LIS values in bottom up manner */
    for (i = 1; i < n; i++)
        for (j = 0; j < i; j++)
            if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
                lis[i] = lis[j] + 1;
 
    /* Pick maximum of all LIS values */
    for (i = 0; i < n; i++)
        if (max < lis[i])
            max = lis[i];
 
    /* Free memory to avoid memory leak */
    free(lis);
 
    return max;
}
 

// ll lisb(ll arr, ll n){
//     ll lis[n];
//     lis[0]=1;
//     for(ll i=1;i<n;i++){
//         lis[i]=1;
//         for(ll j=0;j<i;j++){
//             if(arr[j]<arr[i]){
//                 lis[i]= max(lis[i], lis[j]+1);
//             }
//         }
//     }
//     ll res=0;
//     for(ll i=0;i<n;i++){
//         res= max(res, lis[i]);
//     }
//     return res;
// }

void solve(){
    ll n;cin>>n;
    ll h[n],s[n];
    forn(i,n){
        cin>>h[i];
    }
    forn(i,n){
        cin>>s[i];
    }
    vpll v;
    forn(i,n){
        v.pb({h[i],s[i]});
    }
    sort(v.begin(),v.end());
    ll i=1,c=1;
    ll maxx= v[0].second,smaxx=-1;
    while(i<n){
        if(v[i].first!= v[i-1].first){
            if(v[i].second>= maxx){
                maxx= v[i].second;
            }else if(v[i].second>smaxx){
                
                c++;
                maxx= v[i].first;
            }else{

            }
        }
        i++;
    }
    if(c>=3){
        cout<<"YES";
    }else{
        cout<<"NO";
    }
   

}
int main()
{
    fast_cin();
    ll t;
    cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}