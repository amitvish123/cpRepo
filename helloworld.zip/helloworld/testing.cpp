#include <bits/stdc++.h>
using namespace std;

int main() {
	// your code goes here
	int t;
    cin>>t;
	while(t--){
	int n;cin>>n;
	map<string , int> m;
	for(int i=0;i<n;i++){
	    string s;
	    cin>>s;
	    m[s]++;
	}
    for(auto it= m.rbegin();it!= m.rend();it++){
        cout<<it->second<<" ";
    }
    cout<<endl;
	}
	return 0;
}
