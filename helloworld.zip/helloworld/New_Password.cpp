#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>  
#include <complex>
#include <queue>
#include <set>
#include <unordered_set>
#include <list>
#include <chrono>
#include <random>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <fstream>
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef pair<int,int> p;
typedef pair<ll,ll> pll;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<int> v;
typedef vector<vector<int> > vv;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<p> vp;
ll MOD = 998244353;
double eps = 1e-12;
#define forn(i,e) for(ll i = 0; i < e; i++)
#define forsn(i,s,e) for(ll i = s; i < e; i++)
#define rforn(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
 

void solve(){
    int n;cin>>n;
    string s;
    cin>>s;
    set<char> a,b,c,d;
    a.insert('#');
    a.insert('@');a.insert('*');a.insert('&');
    for(char i='A';i<= 'Z';i++){
        b.insert((char)i);
    }
    for(char i='a';i<='z';i++){
        c.insert((char)i);
    }
    for(char i='0';i<='9';i++){
        d.insert((char)i);
    }
    bool f=false,g= false,h=false,p=false;
    for(ll i=0;i<n;i++){
        if(a.find(s[i])!= a.end()){
            f=true;break;
        }
    }
     for(ll i=0;i<n;i++){
        if(b.find(s[i])!= b.end()){
            g=true;break;
        }
    }
     for(ll i=0;i<n;i++){
        if(c.find(s[i])!= c.end()){
            h=true;break;
        }
    }
     for(ll i=0;i<n;i++){
        if(d.find(s[i])!= d.end()){
            p=true;break;
        }
    }
    if(f==false){
        s.push_back('@');
    }
    if(g==false){
        s.push_back('A');
    }
    if(h==false){
        s.push_back('a');
    }
    if(p==false){
        s.push_back('1');
    }
    ll m= s.length();
    if(m<7){
        for(int i=0;i<7-m;i++){
            s.push_back('1');
        }
    }
    cout<<s;

}
int main()
{
    fast_cin();
    ll t;
    cin >> t;
    ll i=1;
    while(t--) {
       cout<<"Case #"<<i<<": "; solve();cout<<ln;
       i++;
    }
    return 0;
}