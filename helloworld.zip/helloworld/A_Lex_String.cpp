#include<bits/stdc++.h>
using namespace std;
 
typedef long long ll;
#define ln "\n";

void solve(){
    ll n,m,k;
    string s,ss;
    cin>>n>>m>>k;
    cin>>s>>ss;
    ll i=0,j=0,c=0,cc=0;
    string ans;
    ans= s+ss;
    sort(s.begin(),s.end());
    sort(ss.begin(),ss.end());
    while(i<n and j<m){
        if(s[i]-'a'<ss[j]-'a'){
            cout<<s[i];i++;c++;
        }else{
            cout<<ss[j];j++;cc++;
        }
        if(i<n and j<m){
            if(c==k){
                cout<<ss[j];j++;c=0;cc=0;
            }
            if(cc==k){
                cout<<s[i];i++;cc=0;c=0;
            }
        }
    }
    
}
int main()
{
    //fast_cin();
    ll t;
    cin >> t;
    while(t--) {
        solve();cout<<ln;
    }
    return 0;
}