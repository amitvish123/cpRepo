#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    int t;cin>>t;
    while(t--){
        int n;cin>>n;
        if((n/100)+(n%100)<=10){
            cout<<n/100+(n%100)<<endl;
        }else{
            cout<<-1<<endl;
        }
    }
}