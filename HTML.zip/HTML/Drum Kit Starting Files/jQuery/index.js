$("h1").addClass("big-title");
