const express = require("express");
const router = express.Router();
const ChartController = require('../controllers/chart.controller');

// Create routes for chart here
module.exports = router;