const express = require("express");
const router = express.Router();
const SongsController = require('../controllers/songs.controller');

// Create routes for user here
module.exports = router;