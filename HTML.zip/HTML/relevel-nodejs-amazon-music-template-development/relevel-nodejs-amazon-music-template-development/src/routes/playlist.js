const express = require("express");
const router = express.Router();
const PlaylistController = require('../controllers/playlist.controller');

// Create playlist for auth here
module.exports = router;