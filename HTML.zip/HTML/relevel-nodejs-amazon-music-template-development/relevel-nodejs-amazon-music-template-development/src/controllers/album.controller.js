const createAlbum = (req, res) => {
    //createAlbum api logic here
};

const AlbumController = {
    createAlbum
};

module.exports = AlbumController;