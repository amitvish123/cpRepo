const router = require("express").Router();
const { PlayList, validate } = require("../models/playList");
const { Song } = require("../models/song");
const { User } = require("../models/user");
const auth = require("../middleware/auth");
const validateObjectId = require("../middleware/validateObjectId");
const Joi = require("joi");

const createPlaylist = (req, res) => {
    //createPlaylist api logic here
    router.post("/", auth, async (req, res) => {
        const { error } = validate(req.body);
        if (error) return res.status(400).send({ message: error.details[0].message });
    
        const user = await User.findById(req.user._id);
        const playList = await PlayList({ ...req.body, user: user._id }).save();
        user.playlists.push(playList._id);
        await user.save();
    
        res.status(201).send({ data: playList });
    });

};

const deletePlaylist = (req, res) => {
    //deletePlaylist api logic here
    router.delete("/:id", [validateObjectId, auth], async (req, res) => {
        const user = await User.findById(req.user._id);
        const playlist = await PlayList.findById(req.params.id);
        if (!user._id.equals(playlist.user))
            return res
                .status(403)
                .send({ message: "User don't have access to delete!" });
    
        const index = user.playlists.indexOf(req.params.id);
        user.playlists.splice(index, 1);
        await user.save();
        await playlist.remove();
        res.status(200).send({ message: "Removed from library" });
    });
};

const addASongToPlaylist = (req, res) => {
    //addASongToPlaylist api logic here
    router.put("/add-song", auth, async (req, res) => {
        const schema = Joi.object({
            playlistId: Joi.string().required(),
            songId: Joi.string().required(),
        });
        const { error } = schema.validate(req.body);
        if (error) return res.status(400).send({ message: error.details[0].message });
    
        const user = await User.findById(req.user._id);
        const playlist = await PlayList.findById(req.body.playlistId);
        if (!user._id.equals(playlist.user))
            return res.status(403).send({ message: "User don't have access to add!" });
    
        if (playlist.songs.indexOf(req.body.songId) === -1) {
            playlist.songs.push(req.body.songId);
        }
        await playlist.save();
        res.status(200).send({ data: playlist, message: "Added to playlist" });
    });
};

const removeSongFromPlaylist = (req, res) => {
    //removeSongFromPlaylist api logic here
    router.put("/remove-song", auth, async (req, res) => {
        const schema = Joi.object({
            playlistId: Joi.string().required(),
            songId: Joi.string().required(),
        });
        const { error } = schema.validate(req.body);
        if (error) return res.status(400).send({ message: error.details[0].message });
    
        const user = await User.findById(req.user._id);
        const playlist = await PlayList.findById(req.body.playlistId);
        if (!user._id.equals(playlist.user))
            return res
                .status(403)
                .send({ message: "User don't have access to Remove!" });
    
        const index = playlist.songs.indexOf(req.body.songId);
        playlist.songs.splice(index, 1);
        await playlist.save();
        res.status(200).send({ data: playlist, message: "Removed from playlist" });
    });
};

const PlaylistController = {
    createPlaylist,
    deletePlaylist,
    addASongToPlaylist,
    removeSongFromPlaylist
};

module.exports = PlaylistController;