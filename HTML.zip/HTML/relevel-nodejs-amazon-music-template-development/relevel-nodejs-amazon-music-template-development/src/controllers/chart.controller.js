const getMostPopularSongs = (req, res) => {
    //getMostPopularSongs api logic here
    
};


const getRecentlyAddedSongs = (req, res) => {
    //getRecentlyAddedSongs api logic here
};



const ChartController = {
    getMostPopularSongs,
    getRecentlyAddedSongs
};

module.exports = ChartController;