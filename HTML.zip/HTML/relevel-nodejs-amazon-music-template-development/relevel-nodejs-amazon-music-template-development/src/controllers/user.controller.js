const registerUser = (req, res) => {
    //registerUser api logic here
};

const UserController = {
    registerUser
};

module.exports = UserController;