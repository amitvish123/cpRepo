const router = require("express").Router();
const { User } = require("../models/user");
const { Song, validate } = require("../models/song");
const auth = require("../middleware/auth");
const admin = require("../middleware/admin");
const validateObjectId = require("../middleware/validateObjectId");

const addSong = (req, res) => {
    //addSong api logic here
    router.post("/", admin, async (req, res) => {
        const { error } = validate(req.body);
        if (error) res.status(400).send({ message: error.details[0].message });
    
        const song = await Song(req.body).save();
        res.status(201).send({ data: song, message: "Song created successfully" });
    });
};

const removeSong = (req, res) => {
    //removeSong api logic here
    router.delete("/:id", [validateObjectId, admin], async (req, res) => {
        await Song.findByIdAndDelete(req.params.id);
        res.status(200).send({ message: "Song deleted sucessfully" });
    });
    
};

const searchSongByName = (req, res) => {
    //searchSongByName api logic here
};

const searchSongByGenre = (req, res) => {
    //searchSongByGenre api logic here
};

const SongsController = {
    addSong,
    removeSong,
    searchSongByName,
    searchSongByGenre
};

module.exports = SongsController;