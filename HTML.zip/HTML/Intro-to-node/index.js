var superheroes= require("superheroes");

var mySuperheroes= superheroes.random();
console.log(mySuperheroes);