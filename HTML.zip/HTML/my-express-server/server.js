const express= require("express");

const app= express();

app.get('/',function(req, res){
    res.send("<h1>Hello! How are you?</h1>")
})

app.get('/about',function(req,res){
    res.send("I am a student who loves challenges.")
})
app.listen(3000, function(){
    console.log("Server is running on port 3000");
})